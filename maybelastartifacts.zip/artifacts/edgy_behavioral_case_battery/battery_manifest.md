# Edgy Behavioral Case Battery

- generated_at: 2026-04-12T18:29:56.659070+00:00
- case_count: 16
- traces_dir: C:\Users\Thanatos\Desktop\UmbraProtocol_MORA\artifacts\edgy_behavioral_case_battery\traces

| case_id | family | paired_with | key_tension_axis | what_to_inspect_in_trace |
|---|---|---|---|---|
| world_absent_no_basis | world_absence_poverty | world_partial_observation_only | world_presence:none, world_grounding:required | world_adapter, world_entry_contract, world_seam_enforcement, downstream_obedience, subject_tick |
| world_partial_observation_only | world_absence_poverty | world_absent_no_basis | world_presence:partial, effect_basis:missing, action_projection:present | world_adapter, world_entry_contract, s01_efference_copy, s02_prediction_boundary, subject_tick |
| world_contradictory_uncorrelated_effect | world_absence_poverty | world_correlated_effect_reference | world_effect_correlation:false, seam_integrity:stressed | world_adapter, world_entry_contract, world_seam_enforcement, s02_prediction_boundary, bounded_outcome_resolution |
| world_correlated_effect_reference | world_absence_poverty | world_contradictory_uncorrelated_effect | world_effect_correlation:true, seam_integrity:improved | world_adapter, world_entry_contract, world_seam_enforcement, downstream_obedience, subject_tick |
| epistemic_weak_report_low_conf | epistemic_fragility | epistemic_report_observation_required | epistemic_status:report, confidence:low | epistemics, regulation, t03_hypothesis_competition, subject_tick |
| epistemic_report_observation_required | epistemic_fragility | epistemic_weak_report_low_conf | epistemic_require_observation:true, signal:report_low | epistemics, c05_temporal_validity, bounded_outcome_resolution, subject_tick |
| epistemic_quasi_observation_non_sensor | epistemic_fragility | epistemic_true_sensor_observation | source_class:reporter, modality:sensor_stream, quasi_observation:true | epistemics, world_entry_contract, s02_prediction_boundary, subject_tick |
| epistemic_true_sensor_observation | epistemic_fragility | epistemic_quasi_observation_non_sensor | source_class:sensor, modality:sensor_stream, confidence:high | epistemics, regulation, bounded_outcome_resolution, subject_tick |
| regulation_high_pressure_guarded_continue | regulation_mode_validity_pressure | regulation_emergency_override_detour | pressure:high, override_scope:narrow, detour:none_or_light | regulation, c04_mode_arbitration, c05_temporal_validity, subject_tick |
| regulation_emergency_override_detour | regulation_mode_validity_pressure | regulation_high_pressure_guarded_continue | pressure:critical, override_scope:emergency, detour:expected | regulation, c04_mode_arbitration, bounded_outcome_resolution, downstream_obedience, subject_tick |
| mode_quiescent_safe_idle_conflict | regulation_mode_validity_pressure | mode_endogenous_relief_variant | endogenous_tick:disabled, mode_source:quiescent | c04_mode_arbitration, c05_temporal_validity, bounded_outcome_resolution, subject_tick |
| mode_endogenous_relief_variant | regulation_mode_validity_pressure | mode_quiescent_safe_idle_conflict | endogenous_tick:enabled, resource_budget:high | c04_mode_arbitration, c05_temporal_validity, subject_tick |
| temporal_validity_tight_revalidation | regulation_mode_validity_pressure | temporal_validity_permissive_reuse | validity:revalidation_required, legality:no_full_collapse | c05_temporal_validity, bounded_outcome_resolution, subject_tick |
| temporal_validity_permissive_reuse | regulation_mode_validity_pressure | temporal_validity_tight_revalidation | validity:reuse_allowed, revalidation_required:false | c05_temporal_validity, bounded_outcome_resolution, subject_tick |
| ownership_prediction_memory_narrative_temptation_weak | ownership_self_prediction_instability | ownership_prediction_memory_narrative_temptation_stronger | ownership_ambiguity:high, prediction_boundary:stressed, memory_claim:required_without_basis, narrative_claim:required_without_basis | s01_efference_copy, s02_prediction_boundary, s03_ownership_weighted_learning, s_minimal_contour, m_minimal, n_minimal, subject_tick |
| ownership_prediction_memory_narrative_temptation_stronger | memory_narrative_temptation | ownership_prediction_memory_narrative_temptation_weak | ownership_basis:improved, prediction_boundary:stronger_signal, memory_narrative_pressure:same | world_adapter, s02_prediction_boundary, s03_ownership_weighted_learning, s_minimal_contour, m_minimal, n_minimal, subject_tick |
